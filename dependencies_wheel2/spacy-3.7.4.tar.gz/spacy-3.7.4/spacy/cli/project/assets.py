from weasel.cli.assets import *
