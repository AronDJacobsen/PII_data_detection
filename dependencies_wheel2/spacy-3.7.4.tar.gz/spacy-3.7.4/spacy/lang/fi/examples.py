"""
Example sentences to test spaCy and its language models.
>>> from spacy.lang.fi.examples import sentences
>>> docs = nlp.pipe(sentences)
"""

sentences = [
    "Itseajavat autot siirtävät vakuutusvastuun autojen valmistajille",
    "San Francisco harkitsee toimitusrobottien liikkumisen kieltämistä jalkakäytävillä",
    "Lontoo on suuri kaupunki Yhdistyneessä Kuningaskunnassa.",
    "Missä sinä olet?",
    "Mikä on Yhdysvaltojen pääkaupunki?",
    "Kuka on Suomen presidentti?",
    "Milloin Sauli Niinistö on syntynyt?",
]
