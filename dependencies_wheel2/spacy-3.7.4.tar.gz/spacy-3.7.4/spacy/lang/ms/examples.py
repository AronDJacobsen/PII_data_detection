"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.ms.examples import sentences
>>> docs = nlp.pipe(sentences)
"""


sentences = [
    "Malaysia ialah sebuah negara yang terletak di Asia Tenggara.",
    "Berapa banyak pelajar yang akan menghadiri majlis perpisahan sekolah?",
    "Pengeluaran makanan berasal dari beberapa lokasi termasuk Cameron Highlands, Johor Bahru, dan Kuching.",
    "Syarikat XYZ telah menghasilkan 20,000 unit produk baharu dalam setahun terakhir",
    "Kuala Lumpur merupakan ibu negara Malaysia." "Kau berada di mana semalam?",
    "Siapa yang akan memimpin projek itu?",
    "Siapa perdana menteri Malaysia sekarang?",
]
